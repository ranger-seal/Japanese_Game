﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media; //引入这个命名空间，否则无法播放音乐

namespace 匹配游戏
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent(); //初始化窗体
			AssignIconsToSquares(); //调用随机排列假名方法即打开窗体就是随机排列假名
			backGroundMusic.Play(); //初始化窗体时先播放一段背景音乐
		}

		//采用相对地址的方式定义音乐变量：backGroundMusic、matchMusic、notMatchMusic
		SoundPlayer backGroundMusic = new SoundPlayer(Application.StartupPath + @"\backGroundMusic.wav");
		SoundPlayer matchMusic = new SoundPlayer(Application.StartupPath + @"\matchMusic.wav");
		SoundPlayer notMatchMusic = new SoundPlayer(Application.StartupPath + @"\notMatchMusic.wav");

		//引入两个变量，分别跟踪第一次和第二次点击了哪两个label
		Label first_click = null; // 第一次点击
		Label second_click = null; // 第二次点击
		List<string> icons = new List<string>() //初始化一个string类型的列表，用于装100个假名
		{					"あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ","た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ","ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん","ア","イ","ウ","エ","オ","カ","キ","ク","ケ","コ","サ","シ","ス","セ","ソ","タ","チ","ツ","テ","ト","ナ","ニ","ヌ","ネ","ノ","ハ","ヒ","フ","ヘ","ホ","マ","ミ","ム","メ","モ","ヤ","ユ","ヨ","ラ","リ","ル","レ","ロ","ワ","ヲ","ン","が","ガ","ぎ","ギ","ぐ","グ","げ","ゲ"
		};

		private void AssignIconsToSquares() //声明一个方法，给100个控件随机分配假名
		{
			Random random = new Random();	//实例化random内置方法
			foreach (Control controls in tableLayoutPanel1.Controls) //Control类有个Controls属性，表示当前控件所包含的控件，此句为遍历tableLayoutPanel1中的所有控件
			{
				Label iconLabel = controls as Label; //把control类的实例转换成label类的实例
				if (iconLabel != null) //判断是否转换成功，详见as关键字使用方法
				{
					int randomnumber = random.Next(icons.Count);//获取List对象icons中元素个数打乱顺序并计数。
					iconLabel.Text = icons[randomnumber];//控件显示的是列表中的任一随机数
					icons.RemoveAt(randomnumber); //移除列表中已经随机排列过的元素，保证假名随机排列不会重复。
				}
			}
		}

		private void label_Click(Object sender, EventArgs e) //这里要把100个label空间提前都放入同一个label_Click事件中
		{
			Label click_libel = sender as Label;
			//Label click_libel2 = sender as Label;
            if (first_click == null) //判空，判断是否已经执行第一次点击
            {
				
                first_click = click_libel; //采集第一次点击
				click_libel.BackColor = Color.Red;
				return; //跳出if语句
            }
			second_click = click_libel; //采集第二次点击
			click_libel.BackColor = Color.Red;
			List<string> my_list = new List<string>(); //声明一个空列表用于接点击的控件的text属性的值
			my_list.Add(first_click.Text); //将第一次点击的text值压入数组
			my_list.Add(second_click.Text);//将第二次点击的text值压入数组
			string c1, c2; 
			char a1, a2; //sting类型的变量无法直接转换成int类型，所以用char类型中转一下
			c1 = my_list[0];
			c2 = my_list[1];
			a1 = Convert.ToChar(c1); //将点击的值转换成编码
			a2 = Convert.ToChar(c2); //将点击的值转换成编码
			//这里采用比较值的方法来判断平假名片假名是否是同一个假名，平片编码值相差96
			if (System.Math.Abs(Convert.ToInt32(a1) - Convert.ToInt32(a2)) == 96) //因为不确定先点的是平假还是片假所以加个abs()取绝对值方法
			{
				//MessageBox.Show("Right");
				matchMusic.Play(); //运行匹配成功的音乐文件
				//如果选择正确则把点击的控件的值都赋空，也就是视觉上实现相同即消失的功能
				first_click.Text = ""; 
				second_click.Text = "";
				//清空两次点击变量的值，为下一次点击做准备
				first_click = null;
				second_click = null;
			}
			else
			{
				notMatchMusic.Play(); //运行匹配失败的音乐文件

				MessageBox.Show("Wrong");//选择错误弹出一个wrong的提示
										 //并且清空两次点击变量的值，为下一次点击做准备
				first_click.BackColor = Color.White;
				second_click.BackColor = Color.White;
				first_click = null;
				second_click = null;
			}
		}
	}
}
